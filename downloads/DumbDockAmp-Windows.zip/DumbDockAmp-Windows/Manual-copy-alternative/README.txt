Alternative to the installer: copy the folder 'DumbDock Amp.vst3' into C:\Program Files\Common Files\VST3 and re-scan in Reaper.
